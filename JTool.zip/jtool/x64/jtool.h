#ifndef _JTOOL_H
#define _JTOOL_H
#include <stdint.h>

typedef int BOOL;

typedef enum
{
	dev_all = -1,
	dev_i2c = 0,
	dev_io,
	dev_spi,
	dev_can,
	dev_max,
}dev_type_enum;

typedef enum
{
	ErrNone = 0,//�ɹ�
	ErrParam = 1 << 0,//��������
	ErrDisconnect = 1 << 1,//USB �Ͽ�
	ErrBusy = 1 << 2,//USB����æ
	ErrWaiting = 1 << 3,//���ڵȴ��ظ�
	ErrTimeOut = 1 << 4,//ͨ�ų�ʱ
	ErrDataParse = 1 << 5,//ͨ�����ݴ���
	ErrFailACK = 1 << 6,//����ʧ�ܲ���
} ErrorType;

typedef enum
{
	INT_NONE = 0,//��
	INT_RISE = 1,//������
	INT_FALL = 2,//�½���
	INT_HIGH = 3,//�ߵ�ƽ
	INT_LOW = 4,//�͵�ƽ
	INT_RISE_FALL = 5,//˫����
}INT_TYPE;
//�豸����API
extern __declspec(dllexport) char* DevicesScan(int DevType, int* OutCnt);
extern __declspec(dllexport) void* DevOpen(int DevType, char* Sn, int Id);
extern __declspec(dllexport) BOOL DevClose(void* DevHandle);

//JIO API
extern __declspec(dllexport) ErrorType IOSetNone(void* DevHandle, uint32_t ionum);
extern __declspec(dllexport) ErrorType IOSetNone_m(void* DevHandle, uint32_t iomask);
extern __declspec(dllexport) ErrorType IOSetIn(void* DevHandle, uint32_t ionum, BOOL pullup, BOOL pulldown);
extern __declspec(dllexport) ErrorType IOSetIn_m(void* DevHandle, uint32_t iomask, uint32_t pullups, uint32_t pulldowns);
extern __declspec(dllexport) ErrorType IOSetOut(void* DevHandle, uint32_t ionum, BOOL pp);
extern __declspec(dllexport) ErrorType IOSetOut_m(void* DevHandle, uint32_t iomask, uint32_t pps);
extern __declspec(dllexport) ErrorType IOSetVal(void* DevHandle, uint32_t ionum, BOOL val);
extern __declspec(dllexport) ErrorType IOSetVal_m(void* DevHandle, uint32_t iomask, uint32_t vals);
extern __declspec(dllexport) ErrorType IOSetOutWithVal(void* DevHandle, uint32_t ionum, BOOL pp, BOOL val);
extern __declspec(dllexport) ErrorType IOSetOutWithVal_m(void* DevHandle, uint32_t iomask, uint32_t pps, uint32_t vals);
extern __declspec(dllexport) ErrorType IOPulseOn(void* DevHandle, uint32_t ionum, uint32_t freq);
extern __declspec(dllexport) ErrorType IOPulseOn_m(void* DevHandle, uint32_t iomask, uint32_t* freqs);
extern __declspec(dllexport) ErrorType IOPulseOff(void* DevHandle, uint32_t ionum);
extern __declspec(dllexport) ErrorType IOPulseOff_m(void* DevHandle, uint32_t iomask);
extern __declspec(dllexport) ErrorType IOPulseCnt(void* DevHandle, uint32_t ionum, uint32_t cnt, uint32_t freq);
extern __declspec(dllexport) ErrorType IOPulseCnt_m(void* DevHandle, uint32_t iomask, uint32_t* cnts, uint32_t* freqs);
extern __declspec(dllexport) ErrorType IOPulseFreq(void* DevHandle, uint32_t ionum, uint32_t freq);
extern __declspec(dllexport) ErrorType IOPulseFreq_m(void* DevHandle, uint32_t iomask, uint32_t* freqs);

extern __declspec(dllexport) ErrorType PWMSetFreq(void* DevHandle, uint32_t freq);
extern __declspec(dllexport) ErrorType PWMSetOut(void* DevHandle, uint32_t ionum);
extern __declspec(dllexport) ErrorType PWMSetOut_m(void* DevHandle, uint32_t iomask);
extern __declspec(dllexport) ErrorType PWMSetOn(void* DevHandle, uint32_t ionum);
extern __declspec(dllexport) ErrorType PWMSetOn_m(void* DevHandle, uint32_t iomask);
extern __declspec(dllexport) ErrorType PWMSetOff(void* DevHandle, uint32_t ionum);
extern __declspec(dllexport) ErrorType PWMSetOff_m(void* DevHandle, uint32_t iomask);
extern __declspec(dllexport) ErrorType PWMSetDuty(void* DevHandle, uint32_t ionum, uint16_t duty);
extern __declspec(dllexport) ErrorType PWMSetDuty_m(void* DevHandle, uint32_t iomask, uint16_t* dutys);

extern __declspec(dllexport) ErrorType CapSetIn(void* DevHandle, uint32_t ionum);
extern __declspec(dllexport) ErrorType CapClearCnt(void* DevHandle, uint32_t ionum);

extern __declspec(dllexport) ErrorType ADCSetIn(void* DevHandle, uint32_t ionum, BOOL isdiff);
extern __declspec(dllexport) ErrorType ADCSetIn_m(void* DevHandle, uint32_t iomask, uint32_t isdiffs);
extern __declspec(dllexport) ErrorType ADCSetSamp(void* DevHandle, uint32_t samp);

extern __declspec(dllexport) ErrorType IOGetInVal(void* DevHandle, uint32_t ionum, BOOL* val);
extern __declspec(dllexport) ErrorType IOGetInVal_m(void* DevHandle, uint32_t iomask, uint32_t* vals);
extern __declspec(dllexport) ErrorType IOGetPulseRemain(void* DevHandle, uint32_t ionum, uint32_t* remaincnt);
extern __declspec(dllexport) ErrorType IOGetPulseRemain_m(void* DevHandle, uint32_t iomask, uint32_t* remaincnts);
extern __declspec(dllexport) ErrorType CapGetVal(void* DevHandle, uint32_t ionum, uint32_t* freq, uint16_t* duty, uint32_t* pulsecnt);
extern __declspec(dllexport) ErrorType ADCGetVal(void* DevHandle, uint32_t ionum, uint16_t* adval);
extern __declspec(dllexport) ErrorType ADCGetVal_m(void* DevHandle, uint32_t iomask, uint16_t* advals);

extern __declspec(dllexport) ErrorType JIOReboot(void* DevHandle);
extern __declspec(dllexport) ErrorType JIOSetVcc(void* DevHandle, uint8_t val);
extern __declspec(dllexport) ErrorType JIOSetVio(void* DevHandle, uint8_t val);
extern __declspec(dllexport) ErrorType JIOSetHardVersion(void* DevHandle, char* version);
extern __declspec(dllexport) ErrorType JIOSetID(void* DevHandle, uint16_t val);
extern __declspec(dllexport) ErrorType JIOIntoBoot(void* DevHandle);


//JI2C API
typedef enum
{
	REGADDR_NONE = 0,//�����͵�ַ
	REGADDR_8Bit = 1,//����8λ��ַ
	REGADDR_16Bit = 2,//����16λ��ַ
	REGADDR_24Bit = 3,//����24λ��ַ
	REGADDR_32Bit = 4,//����32λ��ַ
}REGADDR_TYPE;
extern __declspec(dllexport) ErrorType I2CScan(void* DevHandle, uint8_t* cnt, uint8_t* result);
extern __declspec(dllexport) ErrorType I2CWrite(void* DevHandle, uint8_t slave_addr, REGADDR_TYPE reg_type, uint32_t reg_addr, uint16_t len, uint8_t* data);
extern __declspec(dllexport) ErrorType I2CRead(void* DevHandle, uint8_t slave_addr, REGADDR_TYPE reg_type, uint32_t reg_addr, uint16_t len, uint8_t* buf);
extern __declspec(dllexport) ErrorType I2CReadWithDelay(void* DevHandle, uint8_t slave_addr, REGADDR_TYPE reg_type, uint32_t reg_addr, uint16_t len, uint8_t* buf, uint8_t sr_delay, uint8_t raddr_delay);
extern __declspec(dllexport) ErrorType EEWrite(void* DevHandle, uint8_t base_slave_addr, REGADDR_TYPE reg_type, uint16_t page_size, uint32_t reg_addr, uint32_t len, uint8_t* data);
extern __declspec(dllexport) ErrorType EERead(void* DevHandle, uint8_t base_slave_addr, REGADDR_TYPE reg_type, uint32_t reg_addr, uint32_t len, uint8_t* buf);

typedef void (*I2CIntCallbackFun)(void);
extern __declspec(dllexport) ErrorType I2CRegisterIntCallback(void* DevHandle, INT_TYPE inttype, I2CIntCallbackFun callback);
extern __declspec(dllexport) ErrorType I2CCloseIntCallback(void* DevHandle);

extern __declspec(dllexport) ErrorType JI2CReboot(void* DevHandle);
extern __declspec(dllexport) ErrorType JI2CSetVcc(void* DevHandle, uint8_t val);
extern __declspec(dllexport) ErrorType JI2CSetVio(void* DevHandle, uint8_t val);
extern __declspec(dllexport) ErrorType JI2CSetSpeed(void* DevHandle, uint8_t val);
extern __declspec(dllexport) ErrorType JI2CSetHardVersion(void* DevHandle, char* version);
extern __declspec(dllexport) ErrorType JI2CSetID(void* DevHandle, uint16_t val);
extern __declspec(dllexport) ErrorType JI2CIntoBoot(void* DevHandle);

//JSPI API
typedef enum
{
	SINGLEALL = 0,//���н׶ζ��ǵ���
	QUADALL = 1,//���н׶ζ�������
	QUADDATA = 2,//�����ݽ׶����ߣ���������
	SINGLECMD = 3,//��ָ��׶ε��ߣ���������
}QSPI_TYPE;
typedef enum
{
	LOW_1EDG = 0,
	LOW_2EDG = 1,
	HIGH_1EDG = 2,
	HIGH_2EDG = 3,
} SPICK_TYPE;
typedef enum
{
	ENDIAN_MSB = 0,//��λ��ǰ
	ENDIAN_LSB = 1,//��λ��ǰ
} SPIFIRSTBIT_TYPE;
typedef enum
{
	FIELD_NONE,//��
	FIELD_ONE,//1�ֽ�
	FIELD_TWO,//2�ֽ�
	FIELD_THREE,//3�ֽ�
	FIELD_FOUR,//4�ֽ�
} FIELDLEN_TYPE;
extern __declspec(dllexport) ErrorType SPIWriteOnly(void* DevHandle, SPICK_TYPE ck, SPIFIRSTBIT_TYPE firstbit, uint32_t len, uint8_t* dataw);
extern __declspec(dllexport) ErrorType SPIReadOnly(void* DevHandle, SPICK_TYPE ck, SPIFIRSTBIT_TYPE firstbit, uint32_t len, uint8_t* bufr);
extern __declspec(dllexport) ErrorType SPIWriteRead(void* DevHandle, SPICK_TYPE ck, SPIFIRSTBIT_TYPE firstbit, uint32_t len, uint8_t* dataw, uint8_t* bufr);

extern __declspec(dllexport) ErrorType QSPIWriteOnly(void* DevHandle, SPICK_TYPE ck, SPIFIRSTBIT_TYPE firstbit, uint32_t len, uint8_t* dataw);
extern __declspec(dllexport) ErrorType QSPIReadOnly(void* DevHandle, SPICK_TYPE ck, SPIFIRSTBIT_TYPE firstbit, uint32_t len, uint8_t* bufr);

extern __declspec(dllexport) ErrorType SPIWriteWithCMD(
	void* DevHandle,
	SPICK_TYPE ck,
	SPIFIRSTBIT_TYPE firstbit,
	QSPI_TYPE qspitype,
	FIELDLEN_TYPE cmdtype,
	uint32_t cmd,
	FIELDLEN_TYPE addrtype,
	uint32_t addr,
	FIELDLEN_TYPE alttype,
	uint32_t alt,
	FIELDLEN_TYPE dummytype,
	uint32_t len,
	uint8_t* dataw);
extern __declspec(dllexport) ErrorType SPIReadWithCMD(
	void* DevHandle,
	SPICK_TYPE ck,
	SPIFIRSTBIT_TYPE firstbit,
	QSPI_TYPE qspitype,
	FIELDLEN_TYPE cmdtype,
	uint32_t cmd,
	FIELDLEN_TYPE addrtype,
	uint32_t addr,
	FIELDLEN_TYPE alttype,
	uint32_t alt,
	FIELDLEN_TYPE dummytype,
	uint32_t len,
	uint8_t* bufr);


typedef void (*SPIIntCallbackFun)(void);
extern __declspec(dllexport) ErrorType SPIRegisterIntCallback(void* DevHandle, INT_TYPE inttype, SPIIntCallbackFun callback);
extern __declspec(dllexport) ErrorType SPICloseIntCallback(void* DevHandle);

extern __declspec(dllexport) ErrorType JSPIReboot(void* DevHandle);
extern __declspec(dllexport) ErrorType JSPISetVcc(void* DevHandle, uint8_t val);
extern __declspec(dllexport) ErrorType JSPISetVio(void* DevHandle, uint8_t val);
extern __declspec(dllexport) ErrorType JSPISetSpeed(void* DevHandle, uint8_t val);
extern __declspec(dllexport) ErrorType JSPISetHardVersion(void* DevHandle, char* version);
extern __declspec(dllexport) ErrorType JSPISetID(void* DevHandle, uint16_t val);
extern __declspec(dllexport) ErrorType JSPIIntoBoot(void* DevHandle);



#endif